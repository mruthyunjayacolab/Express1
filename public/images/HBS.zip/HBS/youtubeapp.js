const express=require('express')
const app=express()
const hbs=require('hbs')

app.set('view engine','hbs')
app.set('views','hbsfile')

hbs.registerPartials('./hbsfile/components')


app.use(express.static('public'))

let categories=[
    {title:"All"},
    {title:"Music"},
    {title:"Comedy"},
    {title:"Sports"},
    {title:"News"},
    {title:"Bollywood"},
    {title:"Reality shows"},
    {title:"Live"},
    {title:"Movies"},
    {title:"Kannada"},
    {title:"English"}
]

let videos=[
    {img:'/images/Boss.webp',title:'Boos Kranti',channel:'Woldwide'},
    {img:'/images/hostel.webp',title:'Hostel life',channel:'hostel'},
    {img:'/images/breakup.webp',title:'Breakup',channel:'sad'},
    {img:'/images/banadariyalli.jpg',title:'Banadariyalli',channel:'sad'},
    {img:'/images/love360.webp',title:'Love360',channel:'love'},
    {img:'/images/paramathma.jpg',title:'Paramathma',channel:'mind'},
    {img:'/images/triple-engine.webp',title:'Triple-ingine',channel:'love'},
    {img:'/images/love-birds.webp',title:'Love-birds',channel:'love'},
    {img:'/images/samayave-kadalathira.jpg',title:'Samayave-kadalathira',channel:'sad'},
    {img:'/images/love-mushup.webp',title:'Love-mushup',channel:'love'},
    {img:'/images/banaras.jpg',title:'Banaras',channel:'sad'},
]
app.get('/',(req,res)=>{
    res.render('youtube',{categories,videos})
})

app.listen(4000,()=>{
    console.log("listen at port number 4000");
})