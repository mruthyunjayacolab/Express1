const express=require('express')
const app=express()

app.set('view engine','hbs')
app.set('views','hbsfile') //we can do this type when the folder name cant contain name like viwes

app.get('/',(req,res)=>{
    let db=[
        {name:'pavan',age:24},
        {name:'pavankumar',age:23},
        {name:'pavankumarv',age:25}
    ]
    res.render('home',{title:'hiii title',db})
})

app.listen(7777,()=>{
    console.log('listen');
})